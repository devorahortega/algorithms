array = []

for i in range(9000):
  array.append(i + 1)

print(array)