# this program computes the sum of 
# all numbers from 1 - 100
s = 0
for i in range(100):
	s = s + i + 1
print(s)
# this program computes the sum of 
# all numbers from 1 - 1000
s = 0
for i in range(1000):
	s = s + i + 1
print(s)