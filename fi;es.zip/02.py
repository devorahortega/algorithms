x = 3
y = 4
z = x + y
print(z)